
    import axios from "axios";
 

export const fetchBlogsService = async () => {
  try {
    const response = await axios.get(
      `${process.env.REACT_APP_API_URL}/fetchBlogs` 
    );

    // Handle the response data here

    return response.data;
  } catch (error) {
    throw new Error("fetchBlogs request failed: " + error.message);
  }
};
    