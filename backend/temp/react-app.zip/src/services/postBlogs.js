
    import axios from "axios";
 

export const postBlogsService = async () => {
  try {
    const response = await axios.post(
      `${process.env.REACT_APP_API_URL}/postBlogs` 
    );

    // Handle the response data here

    return response.data;
  } catch (error) {
    throw new Error("postBlogs request failed: " + error.message);
  }
};
    